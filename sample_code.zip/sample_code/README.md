# Transformer Translation Lab 
森 直樹

日本語入力から英語出力を生成する，小さな encoder-decoder Transformer の可視化デモである．

英語版 README: [README_en.md](./README_en.md)

## 目的

このアプリは，言語情報学で Transformer の処理の流れを説明するための教材である．Web Worker 内で小さなモデルを実行し，次の要素を画面上で確認できる．

- encoder self-attention
- shifted-right decoder input
- masked decoder self-attention
- encoder-decoder cross-attention
- autoregressive decoding の各ステップ
- token probability の簡易表示

大規模な事前学習済みモデルは読み込まない．すべてブラウザ内で完結する．

## 実行方法

```bash
npm install
npm run dev
```

`pnpm` でも利用できる (`pnpm install && pnpm run dev`)．

ブラウザで次を開く．

```text
http://127.0.0.1:5173/
```

## 終了方法

dev サーバは次のいずれかで終了する．どの経路でもキャッシュは自動で掃除される．

- 画面右上の「Quit」ボタンを押す．その場でサーバが停止し，タブを閉じてよい旨を表示する．
- ブラウザのタブ (またはウィンドウ) を閉じる．接続が途切れると数秒後にサーバが自動で終了する．リロードでは終了しない．
- ターミナルで Ctrl+C を押す．

「Quit」ボタンとタブを閉じたときの自動終了は dev サーバ専用の機能であり，本番ビルドには含まれない．

## ビルド

```bash
npm run build
```

Dropbox などの同期フォルダ上で `dist` がロックされている場合，Vite が古い `dist/assets` を削除できず `EPERM` で失敗することがある．その場合は同期が落ち着いてから再実行するか，`npm run clean` で `dist` とキャッシュを削除してから実行する．

## キャッシュとクリーンアップ

Vite の依存最適化キャッシュは，プロジェクト内 (`node_modules\.vite`) ではなく OS の一時ディレクトリに置いている．このため Dropbox などの同期フォルダ上でも `EBUSY` を起こさず，プロジェクトフォルダに `.vite` を残さない．

- `npm run dev` は，終了時 (Ctrl+C・通常終了) にこのキャッシュを自動で削除する．
- `dist` も含めて手動で一掃するには `npm run clean` を実行する．

フォルダをまとめて配布・アップロードする前に `npm run clean` を実行すると，キャッシュや成果物が残らない状態にできる．

## 教育用の簡略化

このデモは「Transformer の計算と可視化」を説明するためのものである．一般的な機械翻訳システムとしては設計していない．

主な簡略化は次の通りである．

- 語彙はデモ用の数語に限定している．
- 対応している日本語入力は，プリセット文とそれに近い短文だけである．
- tokenizer は辞書にある語を最長一致で切り出し，未知語は 1 文字ずつ unknown token として扱う．
- 英語の出力計画は，小さなルールベースの文型判定で生成する．
- embedding は事前学習済みではなく，concept と role から決定的に生成した小さなベクトルである．
- attention は scaled dot-product attention を計算するが，教材として見やすくするために role や source alignment に基づく bias を加えている．
- token probability は内部スコアの softmax であり，実モデルの信頼度として解釈するものではない．
- 文法は最低限である．`I am`，`You are`，三人称単数の `is / likes / reads / goes` など，デモに必要な範囲だけを扱う．
- 複数文，長文，助詞の曖昧性，敬語，時制変化，複雑な語順変換には対応していない．

## 対応例

プリセットとして次の文を用意している．

- 私は猫が好きです -> I like cats.
- 彼は学生です -> He is a student.
- これは本です -> This is a book.
- 私はりんごを食べます -> I eat an apple.
- 彼女は本を読みます -> She reads a book.
- 私は明日学校へ行きます -> I go to school tomorrow.
- 今日は暑いです -> It is hot today.
- ありがとう -> Thank you.

## 注意

このアプリの出力は，教材として一貫した可視化を実施するために制御している．未知の文に対する翻訳品質を評価する目的には向かない．
