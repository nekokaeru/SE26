import { defineConfig } from 'vite'
import { cacheDir } from './scripts/cache-dir.mjs'
import { browserShutdownPlugin } from './scripts/shutdown-plugin.mjs'

// cacheDir を OS の一時ディレクトリに逃がす (理由は scripts/cache-dir.mjs を参照)．
// browserShutdownPlugin: 画面の終了ボタン / タブを閉じたときに dev サーバを止める．
export default defineConfig({
  cacheDir,
  plugins: [browserShutdownPlugin()],
})
