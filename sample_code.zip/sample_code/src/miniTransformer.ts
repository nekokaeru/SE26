export type Role =
  | "control"
  | "pronoun"
  | "deictic"
  | "noun"
  | "verb"
  | "adjective"
  | "particle"
  | "copula"
  | "time"
  | "function"
  | "unknown";

export interface Lexeme {
  text: string;
  concept: string;
  role: Role;
  gloss: string;
  english?: string;
}

export interface ModelToken {
  id: string;
  text: string;
  concept: string;
  role: Role;
  gloss: string;
  index: number;
  english?: string;
  source?: number[];
}

export interface AttentionHead {
  name: string;
  weights: number[][];
}

export interface EncoderTrace {
  embeddings: number[][];
  selfAttention: AttentionHead[];
  contextual: number[][];
}

export interface Candidate {
  token: string;
  probability: number;
}

export interface DecodeStep {
  index: number;
  shiftedRight: string[];
  predicted: ModelToken;
  maskedSelfAttention: AttentionHead[];
  crossAttention: AttentionHead[];
  topK: Candidate[];
  encoderPulse: number[];
  decoderPulse: number[];
}

export interface TransformerTrace {
  input: string;
  normalizedInput: string;
  sourceTokens: ModelToken[];
  targetPlan: ModelToken[];
  encoder: EncoderTrace;
  steps: DecodeStep[];
  finalText: string;
  summary: string[];
}

export interface WorkerRequest {
  id: number;
  input: string;
}

export type WorkerResponse =
  | { type: "started"; id: number }
  | { type: "result"; id: number; trace: TransformerTrace }
  | { type: "error"; id: number; message: string };

export const examples = [
  { label: "I like cats", input: "私は猫が好きです" },
  { label: "He is a student", input: "彼は学生です" },
  { label: "This is a book", input: "これは本です" },
  { label: "I eat an apple", input: "私はりんごを食べます" },
  { label: "She reads a book", input: "彼女は本を読みます" },
  { label: "I go to school tomorrow", input: "私は明日学校へ行きます" },
  { label: "It is hot today", input: "今日は暑いです" },
  { label: "Thank you", input: "ありがとう" }
];

const DIM = 16;
const HEAD_DIM = 8;
const SQRT_HEAD = Math.sqrt(HEAD_DIM);

const lexiconData: Lexeme[] = [
  { text: "ありがとう", concept: "thanks", role: "verb", gloss: "thanks", english: "thank" },
  { text: "わたし", concept: "i", role: "pronoun", gloss: "I", english: "I" },
  { text: "私", concept: "i", role: "pronoun", gloss: "I", english: "I" },
  { text: "あなた", concept: "you", role: "pronoun", gloss: "you", english: "you" },
  { text: "彼女", concept: "she", role: "pronoun", gloss: "she", english: "she" },
  { text: "彼", concept: "he", role: "pronoun", gloss: "he", english: "he" },
  { text: "これ", concept: "this", role: "deictic", gloss: "this", english: "this" },
  { text: "今日", concept: "today", role: "time", gloss: "today", english: "today" },
  { text: "明日", concept: "tomorrow", role: "time", gloss: "tomorrow", english: "tomorrow" },
  { text: "猫", concept: "cat", role: "noun", gloss: "cat", english: "cat" },
  { text: "犬", concept: "dog", role: "noun", gloss: "dog", english: "dog" },
  { text: "蛙", concept: "frog", role: "noun", gloss: "frog", english: "frog" },
  { text: "かえる", concept: "frog", role: "noun", gloss: "frog", english: "frog" },
  { text: "カエル", concept: "frog", role: "noun", gloss: "frog", english: "frog" },
  { text: "りんご", concept: "apple", role: "noun", gloss: "apple", english: "apple" },
  { text: "リンゴ", concept: "apple", role: "noun", gloss: "apple", english: "apple" },
  { text: "本", concept: "book", role: "noun", gloss: "book", english: "book" },
  { text: "学生", concept: "student", role: "noun", gloss: "student", english: "student" },
  { text: "先生", concept: "teacher", role: "noun", gloss: "teacher", english: "teacher" },
  { text: "学校", concept: "school", role: "noun", gloss: "school", english: "school" },
  { text: "暑い", concept: "hot", role: "adjective", gloss: "hot", english: "hot" },
  { text: "寒い", concept: "cold", role: "adjective", gloss: "cold", english: "cold" },
  { text: "好き", concept: "like", role: "verb", gloss: "like", english: "like" },
  { text: "食べます", concept: "eat", role: "verb", gloss: "eat", english: "eat" },
  { text: "読みます", concept: "read", role: "verb", gloss: "read", english: "read" },
  { text: "行きます", concept: "go", role: "verb", gloss: "go", english: "go" },
  { text: "です", concept: "be", role: "copula", gloss: "be", english: "is" },
  { text: "は", concept: "topic", role: "particle", gloss: "topic marker" },
  { text: "が", concept: "subject", role: "particle", gloss: "subject marker" },
  { text: "を", concept: "object", role: "particle", gloss: "object marker" },
  { text: "へ", concept: "to", role: "particle", gloss: "direction marker" },
  { text: "に", concept: "to", role: "particle", gloss: "destination/time marker" }
];

const lexicon = lexiconData.sort((a, b) => b.text.length - a.text.length);

const vocabulary: Array<Pick<ModelToken, "text" | "concept" | "role" | "gloss">> = [
  tok("<bos>", "bos", "control", "begin sequence"),
  tok("I", "i", "pronoun", "I"),
  tok("You", "you", "pronoun", "You"),
  tok("you", "you", "pronoun", "you"),
  tok("He", "he", "pronoun", "He"),
  tok("She", "she", "pronoun", "She"),
  tok("This", "this", "deictic", "This"),
  tok("It", "it", "deictic", "It"),
  tok("am", "be", "copula", "am"),
  tok("is", "be", "copula", "is"),
  tok("are", "be", "copula", "are"),
  tok("like", "like", "verb", "like"),
  tok("likes", "like", "verb", "likes"),
  tok("eat", "eat", "verb", "eat"),
  tok("eats", "eat", "verb", "eats"),
  tok("read", "read", "verb", "read"),
  tok("reads", "read", "verb", "reads"),
  tok("go", "go", "verb", "go"),
  tok("goes", "go", "verb", "goes"),
  tok("to", "to", "function", "to"),
  tok("a", "article", "function", "article"),
  tok("an", "article", "function", "article"),
  tok("cats", "cat", "noun", "cats"),
  tok("dogs", "dog", "noun", "dogs"),
  tok("frogs", "frog", "noun", "frogs"),
  tok("cat", "cat", "noun", "cat"),
  tok("dog", "dog", "noun", "dog"),
  tok("frog", "frog", "noun", "frog"),
  tok("apple", "apple", "noun", "apple"),
  tok("book", "book", "noun", "book"),
  tok("student", "student", "noun", "student"),
  tok("teacher", "teacher", "noun", "teacher"),
  tok("school", "school", "noun", "school"),
  tok("hot", "hot", "adjective", "hot"),
  tok("cold", "cold", "adjective", "cold"),
  tok("today", "today", "time", "today"),
  tok("tomorrow", "tomorrow", "time", "tomorrow"),
  tok("thank", "thanks", "verb", "thank"),
  tok("Thank", "thanks", "verb", "thank")
];

function tok(text: string, concept: string, role: Role, gloss: string) {
  return { text, concept, role, gloss };
}

export function runTinyTransformer(input: string): TransformerTrace {
  const normalizedInput = normalizeInput(input);
  const sourceTokens = tokenize(normalizedInput);
  const targetPlan = buildTargetPlan(sourceTokens);
  const encoder = encode(sourceTokens);
  const steps = decode(sourceTokens, targetPlan, encoder);
  const finalText = formatOutput(targetPlan);

  return {
    input,
    normalizedInput,
    sourceTokens,
    targetPlan,
    encoder,
    steps,
    finalText,
    summary: [
      "Encoder self-attention builds a contextual memory over Japanese tokens.",
      "The decoder receives shifted-right English tokens and masks future positions.",
      "Cross-attention aligns the current decoder state with the encoder memory."
    ]
  };
}

function normalizeInput(input: string) {
  const compact = input
    .replace(/[。、,.!?！？]/g, "")
    .replace(/\s+/g, "")
    .trim();
  return compact || examples[0].input;
}

function tokenize(input: string): ModelToken[] {
  const tokens: ModelToken[] = [];
  let cursor = 0;

  while (cursor < input.length) {
    const matched = lexicon.find((item) => input.startsWith(item.text, cursor));
    if (matched) {
      tokens.push({
        id: `src-${tokens.length}`,
        text: matched.text,
        concept: matched.concept,
        role: matched.role,
        gloss: matched.gloss,
        english: matched.english,
        index: tokens.length
      });
      cursor += matched.text.length;
      continue;
    }

    const char = input[cursor];
    tokens.push({
      id: `src-${tokens.length}`,
      text: char,
      concept: `unknown-${char}`,
      role: "unknown",
      gloss: "unknown token",
      index: tokens.length
    });
    cursor += 1;
  }

  return tokens.length > 0 ? tokens : tokenize(examples[0].input);
}

function buildTargetPlan(source: ModelToken[]): ModelToken[] {
  if (hasConcept(source, "thanks")) {
    return outSequence([
      ["Thank", "thanks", "verb", [findConcept(source, "thanks")]],
      ["you", "you", "pronoun", [findConcept(source, "thanks")]]
    ]);
  }

  if (hasConcept(source, "like")) {
    const subject = topicSubject(source) ?? firstRole(source, "pronoun") ?? source[0];
    const liked = beforeConcept(source, "subject") ?? firstNounNot(source, subject) ?? conceptFallback(source, "cat");
    return outSequence([
      englishSubject(subject),
      [isThirdPerson(subject) ? "likes" : "like", "like", "verb", [findConcept(source, "like")]],
      [pluralForLike(liked), liked.concept, "noun", [liked.index]]
    ]);
  }

  if (hasConcept(source, "eat") || hasConcept(source, "read")) {
    const verbConcept = hasConcept(source, "eat") ? "eat" : "read";
    const subject = topicSubject(source) ?? firstRole(source, "pronoun") ?? conceptFallback(source, "i");
    const object = beforeConcept(source, "object") ?? firstNounNot(source, subject) ?? conceptFallback(source, "book");
    const verbText = verbConcept === "eat"
      ? isThirdPerson(subject) ? "eats" : "eat"
      : isThirdPerson(subject) ? "reads" : "read";
    return outSequence([
      englishSubject(subject),
      [verbText, verbConcept, "verb", [findConcept(source, verbConcept)]],
      ...articlePhrase(object)
    ]);
  }

  if (hasConcept(source, "go")) {
    const subject = topicSubject(source) ?? firstRole(source, "pronoun") ?? conceptFallback(source, "i");
    const destination = beforeConcept(source, "to") ?? findToken(source, "school") ?? conceptFallback(source, "school");
    const time = firstRole(source, "time");
    const sequence: OutputTuple[] = [
      englishSubject(subject),
      [isThirdPerson(subject) ? "goes" : "go", "go", "verb", [findConcept(source, "go")]],
      ["to", "to", "function", [destination.index]],
      [englishNoun(destination), destination.concept, "noun", [destination.index]]
    ];
    if (time) sequence.push([time.english ?? time.gloss, time.concept, "time", [time.index]]);
    return outSequence(sequence);
  }

  if (hasConcept(source, "hot") || hasConcept(source, "cold")) {
    const adjective = findToken(source, "hot") ?? findToken(source, "cold") ?? conceptFallback(source, "hot");
    const time = firstRole(source, "time");
    const sequence: OutputTuple[] = [
      ["It", "it", "deictic", [adjective.index]],
      ["is", "be", "copula", [findConcept(source, "be")]],
      [adjective.english ?? adjective.gloss, adjective.concept, "adjective", [adjective.index]]
    ];
    if (time) sequence.push([time.english ?? time.gloss, time.concept, "time", [time.index]]);
    return outSequence(sequence);
  }

  if (hasConcept(source, "be")) {
    const subject = topicSubject(source) ?? firstRole(source, "deictic") ?? firstRole(source, "pronoun") ?? source[0];
    const complement = lastMeaningToken(source, subject) ?? conceptFallback(source, "student");
    const subjectTuple = englishSubject(subject);
    const beText = subjectTuple[0] === "I"
      ? "am"
      : subjectTuple[0] === "You"
        ? "are"
        : "is";
    return outSequence([
      subjectTuple,
      [beText, "be", "copula", [findConcept(source, "be")]],
      ...articlePhrase(complement)
    ]);
  }

  const content = source.filter((token) => token.role !== "particle" && token.role !== "copula");
  return outSequence(
    (content.length ? content : source).map((token) => [
      token.english ?? token.gloss,
      token.concept,
      token.role,
      [token.index]
    ])
  );
}

type OutputTuple = [text: string, concept: string, role: Role, source: number[]];

function outSequence(items: OutputTuple[]): ModelToken[] {
  return items.map(([text, concept, role, source], index) => ({
    id: `out-${index}`,
    text,
    concept,
    role,
    gloss: text,
    index,
    source
  }));
}

function englishSubject(token: ModelToken): OutputTuple {
  const text = token.concept === "this"
    ? "This"
    : token.concept === "he"
      ? "He"
      : token.concept === "she"
        ? "She"
        : token.concept === "you"
          ? "You"
          : "I";
  return [text, token.concept, token.role, [token.index]];
}

function articlePhrase(token: ModelToken): OutputTuple[] {
  if (token.role !== "noun") {
    return [[token.english ?? token.gloss, token.concept, token.role, [token.index]]];
  }

  if (token.concept === "school") {
    return [[englishNoun(token), token.concept, "noun", [token.index]]];
  }

  const article = /^[aeiou]/i.test(englishNoun(token)) ? "an" : "a";
  return [
    [article, "article", "function", [token.index]],
    [englishNoun(token), token.concept, "noun", [token.index]]
  ];
}

function englishNoun(token: ModelToken) {
  return token.concept === "apple"
    ? "apple"
    : token.concept === "book"
      ? "book"
      : token.concept === "student"
        ? "student"
        : token.concept === "teacher"
          ? "teacher"
          : token.concept === "school"
            ? "school"
            : token.english ?? token.gloss;
}

function pluralForLike(token: ModelToken) {
  if (token.concept === "cat") return "cats";
  if (token.concept === "dog") return "dogs";
  if (token.concept === "frog") return "frogs";
  if (token.concept === "apple") return "apples";
  if (token.concept === "book") return "books";
  return englishNoun(token);
}

function isThirdPerson(token: ModelToken) {
  return ["he", "she", "this"].includes(token.concept);
}

function hasConcept(tokens: ModelToken[], concept: string) {
  return tokens.some((token) => token.concept === concept);
}

function findConcept(tokens: ModelToken[], concept: string) {
  return tokens.find((token) => token.concept === concept)?.index ?? 0;
}

function findToken(tokens: ModelToken[], concept: string) {
  return tokens.find((token) => token.concept === concept);
}

function firstRole(tokens: ModelToken[], role: Role) {
  return tokens.find((token) => token.role === role);
}

function topicSubject(tokens: ModelToken[]) {
  const topicIndex = tokens.findIndex((token) => token.concept === "topic");
  return topicIndex > 0 ? tokens[topicIndex - 1] : undefined;
}

function beforeConcept(tokens: ModelToken[], concept: string) {
  const index = tokens.findIndex((token) => token.concept === concept);
  return index > 0 ? tokens[index - 1] : undefined;
}

function firstNounNot(tokens: ModelToken[], except?: ModelToken) {
  return tokens.find((token) => token.role === "noun" && token.index !== except?.index);
}

function lastMeaningToken(tokens: ModelToken[], except?: ModelToken) {
  return [...tokens]
    .reverse()
    .find((token) =>
      token.index !== except?.index &&
      ["noun", "adjective", "time"].includes(token.role)
    );
}

function conceptFallback(tokens: ModelToken[], concept: string): ModelToken {
  const found = findToken(tokens, concept);
  if (found) return found;
  return {
    id: "fallback",
    text: concept,
    concept,
    role: concept === "i" ? "pronoun" : "noun",
    gloss: concept,
    index: 0
  };
}

function encode(tokens: ModelToken[]): EncoderTrace {
  const embeddings = tokens.map((token, index) => embedding(token, index));
  const selfAttention = multiHeadAttention(tokens, tokens, embeddings, embeddings, {
    mode: "encoder"
  });
  const contextual = fuseHeads(selfAttention, embeddings);
  return {
    embeddings,
    selfAttention,
    contextual
  };
}

function decode(source: ModelToken[], target: ModelToken[], encoder: EncoderTrace): DecodeStep[] {
  const bos: ModelToken = {
    id: "bos",
    text: "<bos>",
    concept: "bos",
    role: "control",
    gloss: "begin sequence",
    index: 0,
    source: []
  };
  const steps: DecodeStep[] = [];

  for (let index = 0; index < target.length; index += 1) {
    const prefix = [bos, ...target.slice(0, index)].map((token, tokenIndex) => ({
      ...token,
      index: tokenIndex
    }));
    const prefixVectors = prefix.map((token, tokenIndex) => embedding(token, tokenIndex));
    const maskedSelfAttention = multiHeadAttention(prefix, prefix, prefixVectors, prefixVectors, {
      mode: "decoder-self",
      causal: true
    });
    const decoderContext = fuseHeads(maskedSelfAttention, prefixVectors);
    const next = target[index];
    const decoderQuery = blend(
      decoderContext[decoderContext.length - 1],
      embedding(next, prefix.length),
      0.56
    );
    const crossAttention = multiHeadAttention(
      [{ ...next, index: prefix.length - 1 }],
      source,
      [decoderQuery],
      encoder.contextual,
      {
        mode: "cross",
        plannedSources: next.source ?? []
      }
    );
    const crossVector = weightedSum(
      encoder.contextual,
      crossAttention[0].weights[0]
    );
    const decoderPulse = normalizeVec(blend(decoderQuery, crossVector, 0.5));
    const topK = rankCandidates(decoderPulse, next, target, index);

    steps.push({
      index,
      shiftedRight: prefix.map((token) => token.text),
      predicted: materializeCandidate(topK[0].token, next, index),
      maskedSelfAttention,
      crossAttention,
      topK,
      encoderPulse: crossAttention[0].weights[0],
      decoderPulse
    });
  }

  return steps;
}

function materializeCandidate(text: string, planned: ModelToken, index: number): ModelToken {
  return {
    ...planned,
    id: `pred-${index}`,
    text,
    index
  };
}

interface AttentionOptions {
  mode: "encoder" | "decoder-self" | "cross";
  causal?: boolean;
  plannedSources?: number[];
}

function multiHeadAttention(
  queryTokens: ModelToken[],
  keyTokens: ModelToken[],
  queryVectors: number[][],
  keyVectors: number[][],
  options: AttentionOptions
): AttentionHead[] {
  return [0, 1].map((headIndex) => {
    const weights = queryVectors.map((queryVector, queryIndex) => {
      const scores = keyVectors.map((keyVector, keyIndex) => {
        if (options.causal && keyIndex > queryIndex) return Number.NEGATIVE_INFINITY;
        const query = project(queryVector, headIndex, "q");
        const key = project(keyVector, headIndex, "k");
        const dotScore = dot(query, key) / SQRT_HEAD;
        return dotScore + attentionBias(
          queryTokens[queryIndex],
          keyTokens[keyIndex],
          queryIndex,
          keyIndex,
          headIndex,
          options
        );
      });
      return softmax(scores);
    });

    return {
      name: headIndex === 0 ? "lexical head" : "syntax head",
      weights
    };
  });
}

function attentionBias(
  query: ModelToken,
  key: ModelToken,
  queryIndex: number,
  keyIndex: number,
  headIndex: number,
  options: AttentionOptions
) {
  let bias = 0;

  if (queryIndex === keyIndex && options.mode !== "cross") bias += headIndex === 0 ? 0.85 : 0.35;

  if (options.mode === "encoder") {
    if (headIndex === 0 && query.concept === key.concept) bias += 1.3;
    if (headIndex === 1 && key.role === "particle") bias += Math.max(0, 0.9 - Math.abs(queryIndex - keyIndex) * 0.25);
    if (query.role === "verb" && ["pronoun", "noun", "time"].includes(key.role)) bias += 0.28;
    if (query.role === "noun" && key.role === "particle" && Math.abs(queryIndex - keyIndex) === 1) bias += 0.9;
  }

  if (options.mode === "decoder-self") {
    if (headIndex === 0 && query.role === key.role) bias += 0.35;
    if (headIndex === 1) bias += Math.max(0, 0.65 - Math.abs(queryIndex - keyIndex) * 0.18);
    if (key.role === "control") bias += 0.25;
  }

  if (options.mode === "cross") {
    if (options.plannedSources?.includes(key.index)) bias += headIndex === 0 ? 2.7 : 1.35;
    if (query.concept === key.concept) bias += headIndex === 0 ? 2.2 : 0.8;
    if (headIndex === 1 && ["particle", "copula"].includes(key.role)) bias += 0.7;
    if (query.role === "function" && key.role === "particle") bias += 1.15;
    if (query.role === "copula" && key.role === "copula") bias += 1.4;
  }

  return bias;
}

function fuseHeads(attention: AttentionHead[], values: number[][]) {
  return values.map((value, rowIndex) => {
    const headMix = attention.map((head) => weightedSum(values, head.weights[rowIndex] ?? []));
    return normalizeVec(value.map((component, componentIndex) =>
      component * 0.54 +
      (headMix[0]?.[componentIndex] ?? 0) * 0.28 +
      (headMix[1]?.[componentIndex] ?? 0) * 0.18
    ));
  });
}

function rankCandidates(
  hidden: number[],
  planned: ModelToken,
  target: ModelToken[],
  index: number
): Candidate[] {
  const scores = vocabulary.map((candidate) => {
    const candidateVector = embedding(candidate, index + 1);
    let score = dot(hidden, candidateVector) * 1.4;
    if (candidate.text === planned.text) score += 5.4;
    if (candidate.concept === planned.concept) score += 1.5;
    if (candidate.role === planned.role) score += 0.45;
    if (target[index - 1]?.text === candidate.text) score -= 0.9;
    if (candidate.text === "<bos>") score -= 5;
    return { token: candidate.text, score };
  });
  const probabilities = softmax(scores.map((item) => item.score));
  return scores
    .map((item, scoreIndex) => ({
      token: item.token,
      probability: probabilities[scoreIndex]
    }))
    .sort((a, b) => b.probability - a.probability)
    .slice(0, 5);
}

function embedding(token: Pick<ModelToken, "concept" | "role">, position: number): number[] {
  const concept = seededVector(`concept:${token.concept}`);
  const role = seededVector(`role:${token.role}`);
  const pos = positionalEncoding(position);
  return normalizeVec(concept.map((component, index) =>
    component * 0.74 + role[index] * 0.18 + pos[index] * 0.08
  ));
}

function project(vector: number[], headIndex: number, kind: "q" | "k") {
  const offset = headIndex === 0 ? 0 : 5;
  const tilt = kind === "q" ? 2 : 3;
  return Array.from({ length: HEAD_DIM }, (_, index) => {
    const a = vector[(index + offset) % DIM];
    const b = vector[(index * tilt + headIndex + 1) % DIM];
    return normalizeScalar(a * 0.78 + b * 0.22);
  });
}

function seededVector(seed: string): number[] {
  const base = hash(seed);
  return Array.from({ length: DIM }, (_, index) => {
    const x = Math.sin((base + index * 97.13) * 0.017) * 43758.5453;
    return normalizeScalar((x - Math.floor(x)) * 2 - 1);
  });
}

function positionalEncoding(position: number): number[] {
  return Array.from({ length: DIM }, (_, index) => {
    const denominator = Math.pow(10000, (2 * Math.floor(index / 2)) / DIM);
    return index % 2 === 0
      ? Math.sin(position / denominator)
      : Math.cos(position / denominator);
  });
}

function hash(input: string) {
  let value = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    value ^= input.charCodeAt(index);
    value = Math.imul(value, 16777619);
  }
  return value >>> 0;
}

function dot(a: number[], b: number[]) {
  return a.reduce((sum, value, index) => sum + value * (b[index] ?? 0), 0);
}

function softmax(scores: number[]) {
  const max = Math.max(...scores.filter(Number.isFinite));
  const exps = scores.map((score) => Number.isFinite(score) ? Math.exp(score - max) : 0);
  const total = exps.reduce((sum, value) => sum + value, 0) || 1;
  return exps.map((value) => value / total);
}

function weightedSum(values: number[][], weights: number[]) {
  return Array.from({ length: DIM }, (_, componentIndex) =>
    values.reduce((sum, vector, valueIndex) => sum + (weights[valueIndex] ?? 0) * (vector[componentIndex] ?? 0), 0)
  );
}

function blend(a: number[], b: number[], bWeight: number) {
  return a.map((value, index) => value * (1 - bWeight) + (b[index] ?? 0) * bWeight);
}

function normalizeVec(vector: number[]) {
  const norm = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0)) || 1;
  return vector.map((value) => value / norm);
}

function normalizeScalar(value: number) {
  return Math.max(-1, Math.min(1, value));
}

function formatOutput(tokens: ModelToken[]) {
  const raw = tokens.map((token) => token.text).join(" ");
  return `${raw.charAt(0).toUpperCase()}${raw.slice(1)}.`
    .replace(/\bI am\b/i, "I am")
    .replace(/\bThis is a\b/, "This is a")
    .replace(/\bThank you\./, "Thank you.");
}
