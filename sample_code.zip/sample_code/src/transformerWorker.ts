import { runTinyTransformer } from "./miniTransformer";
import type { WorkerRequest, WorkerResponse } from "./miniTransformer";

self.onmessage = (event: MessageEvent<WorkerRequest>) => {
  const { id, input } = event.data;
  const started: WorkerResponse = { type: "started", id };
  self.postMessage(started);

  try {
    const trace = runTinyTransformer(input);
    const result: WorkerResponse = { type: "result", id, trace };
    self.postMessage(result);
  } catch (error) {
    const failure: WorkerResponse = {
      type: "error",
      id,
      message: error instanceof Error ? error.message : String(error)
    };
    self.postMessage(failure);
  }
};
